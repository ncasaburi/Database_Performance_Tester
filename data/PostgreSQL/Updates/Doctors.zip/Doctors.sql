UPDATE doctors
SET surname  = lower(surname) 
WHERE name LIKE 'A%' OR name LIKE 'F%';

UPDATE doctors
SET profession  = lower(profession) 
WHERE name LIKE 'A%' OR surname LIKE 'F%';


UPDATE doctors 
SET surname = lower(surname) 
WHERE profession like 'Gynecology';

UPDATE doctors
SET surname  = initcap(surname);

