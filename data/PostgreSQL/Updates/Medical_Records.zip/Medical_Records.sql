UPDATE medical_records 
SET   diagnosis = lower(diagnosis) 
WHERE test_results  LIKE 'Abnormal cardiac function test' or test_results like 'Fungal infection';

UPDATE medical_records 
SET   discharge_date  = to_date('2024-03-01','YYYY-MM-DD') 
WHERE admission_date BETWEEN '2019-01-01' AND '2023-12-31';

UPDATE medical_records 
SET   diagnosis = upper(diagnosis);

UPDATE medical_records 
SET   diagnosis = INITCAP(diagnosis);

