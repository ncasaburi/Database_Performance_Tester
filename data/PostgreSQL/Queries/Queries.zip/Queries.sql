SELECT 
    patients.name AS patient_name,
    patients.surname AS patient_surname,
    medical_records.admission_date,
    medical_records.discharge_date,
    medical_records.diagnosis,
    medical_records.treatment,
    medical_records.test_results,
    doctors.name AS doctor_name,
    doctors.surname AS doctor_surname,
    doctors.profession
FROM 
    patients
inner JOIN 
    medical_records ON patients.id_patient = medical_records.id_patient
inner JOIN 
    doctor_medical_records ON medical_records.id_medical_record = doctor_medical_records.id_medical_record
inner JOIN 
    doctors ON doctor_medical_records.id_doctor = doctors.id_doctor
WHERE 
    patients.name = 'Danielle' and patients.surname = 'Johnson'
    ;

SELECT p.*
FROM patients p
inner JOIN 
	medical_records mr ON p.id_patient = mr.id_patient
inner JOIN 
	doctor_medical_records dmr ON mr.id_medical_record = dmr.id_medical_record
inner JOIN 
	doctors d ON dmr.id_doctor = d.id_doctor
WHERE 
	d.name = 'Taylor' AND d.surname = 'Smith';
