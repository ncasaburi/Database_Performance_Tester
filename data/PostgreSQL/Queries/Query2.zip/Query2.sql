SELECT p.*
FROM patients p
inner JOIN 
	medical_records mr ON p.id_patient = mr.id_patient
inner JOIN 
	doctor_medical_records dmr ON mr.id_medical_record = dmr.id_medical_record
inner JOIN 
	doctors d ON dmr.id_doctor = d.id_doctor
WHERE 
	d.name = 'Taylor' AND d.surname = 'Smith';
