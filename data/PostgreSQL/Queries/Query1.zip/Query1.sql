SELECT 
    patients.name AS patient_name,
    patients.surname AS patient_surname,
    medical_records.admission_date,
    medical_records.discharge_date,
    medical_records.diagnosis,
    medical_records.treatment,
    medical_records.test_results,
    doctors.name AS doctor_name,
    doctors.surname AS doctor_surname,
    doctors.profession
FROM 
    patients
inner JOIN 
    medical_records ON patients.id_patient = medical_records.id_patient
inner JOIN 
    doctor_medical_records ON medical_records.id_medical_record = doctor_medical_records.id_medical_record
inner JOIN 
    doctors ON doctor_medical_records.id_doctor = doctors.id_doctor
WHERE 
    patients.name = 'Danielle' and patients.surname = 'Johnson';
