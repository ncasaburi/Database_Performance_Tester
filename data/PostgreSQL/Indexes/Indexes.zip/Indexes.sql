CREATE INDEX idx_patients_name_surname ON patients (name, surname);
CREATE INDEX idx_medical_records_id_patient ON medical_records (id_patient);
CREATE INDEX idx_doctor_medical_records_id_medical_record ON doctor_medical_records (id_medical_record);
CREATE INDEX idx_doctors_id_doctor ON doctors (id_doctor);  
CREATE INDEX idx_patients_id_patient ON patients (id_patient);
CREATE INDEX idx_medical_records_id_medical_record ON medical_records (id_medical_record);
CREATE INDEX idx_doctor_medical_records_id_doctor ON doctor_medical_records (id_doctor);

