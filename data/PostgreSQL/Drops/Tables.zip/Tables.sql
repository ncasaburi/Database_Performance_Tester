drop table public.doctor_medical_records;
drop table public.medical_records;
drop table public.patients;
drop table public.doctors;
