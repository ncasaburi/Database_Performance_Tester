drop table if exists public.doctor_medical_records;
drop table if exists public.medical_records;
drop table if exists public.patients;
drop table if exists public.doctors;
