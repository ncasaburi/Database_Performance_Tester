delete FROM medical_records 
WHERE test_results  LIKE 'Abnormal cardiac function test' or test_results like 'Fungal infection';

delete FROM medical_records 
WHERE admission_date BETWEEN '2019-01-01' AND '2023-12-31';

delete FROM medical_records 
where diagnosis = upper(diagnosis);

delete FROM medical_records;