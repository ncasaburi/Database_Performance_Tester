delete from patients
WHERE name LIKE 'A%' OR name LIKE 'a%';

delete from patients
WHERE birthday BETWEEN '1945-01-01' AND '1977-12-31';

delete from patients;
