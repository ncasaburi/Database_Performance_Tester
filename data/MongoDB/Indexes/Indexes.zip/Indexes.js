db.doctors.createIndex({ name: 1, surname: 1 });
db.doctor_medical_records.createIndex({ id_doctor: 1 });
db.medical_records.createIndex({ id_medical_record: 1 });
db.patients.createIndex({ id_patient: 1 });
db.patients.createIndex({ name: 1, surname: 1});
db.doctor_medical_records.createIndex({ id_medicalrecord: 1 });
db.doctors.createIndex({ id_doctor: 1 });

