[
    {
        "$match": {
            "name": "Taylor",
            "surname": "Smith"
        }
    },
    {
        "$lookup": {
            "from": "doctor_medical_records",
            "localField": "id_doctor",
            "foreignField": "id_doctor",
            "as": "doctor_records"
        }
    },
    {
        "$unwind": "$doctor_records"
    },
    {
        "$lookup": {
            "from": "medical_records",
            "localField": "doctor_records.id_medicalrecord",
            "foreignField": "id_medical_record",
            "as": "medical_records"
        }
    },
    {
        "$unwind": "$medical_records"
    },
    {
        "$lookup": {
            "from": "patients",
            "localField": "medical_records.id_patient",
            "foreignField": "id_patient",
            "as": "patient_details"
        }
    },
    {
        "$unwind": "$patient_details"
    },
    {
        "$project": {
            "patient_name": "$patient_details.name",
            "patient_surname": "$patient_details.surname",
            "birthday": "$patient_details.birthday",
            "gender": "$patient_details.gender",
            "address": "$patient_details.address",
            "city": "$patient_details.city",
            "state": "$patient_details.state",
            "phone": "$patient_details.phone"
        }
    }
]
