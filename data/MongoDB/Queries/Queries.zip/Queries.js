db.patients.aggregate([
    {
        $match: { name:"Danielle", surname:"Johnson"}
    },
    {
        $lookup: {
            from: "medical_records",
            localField: "id_patient",
            foreignField: "id_patient",
            as: "medical_records"
        }
    },
    {
        $unwind: "$medical_records"
    },
    {
        $lookup: {
            from: "doctor_medical_records",
            localField: "medical_records.id_medical_record",
            foreignField: "id_medicalrecord",
            as: "doctor_medical_records"
        }
    },
    {
        $unwind: "$doctor_medical_records"
    },
    {
        $lookup: {
            from: "doctors",
            localField: "doctor_medical_records.id_doctor",
            foreignField: "id_doctor",
            as: "doctor_details"
        }
    },
    {
        $unwind: "$doctor_details"
    },
    {
        $project: {
            patient_name: "$name",
            patient_surname: "$surname",
            admission_date: "$medical_records.admission_date",
            discharge_date: "$medical_records.discharge_date",
            diagnosis: "$medical_records.diagnosis",
            treatment: "$medical_records.treatment",
            test_result: "$medical_records.test_result",
            doctor_name: "$doctor_details.name",
            doctor_surname: "$doctor_details.surname",
            profession: "$doctor_details.profession"
        }
    }
])


db.doctors.aggregate([
  {
    $match: {
      name: "Taylor",
      surname: "Smith"
    }
  },
  {
    $lookup: {
      from: "doctor_medical_records",
      localField: "id_doctor",
      foreignField: "id_doctor",
      as: "doctor_records"
    }
  },
  {
    $unwind: "$doctor_records"
  },
  {
    $lookup: {
      from: "medical_records",
      localField: "doctor_records.id_medicalrecord",
      foreignField: "id_medical_record",
      as: "medical_records"
    }
  },
  {
    $unwind: "$medical_records"
  },
  {
    $lookup: {
      from: "patients",
      localField: "medical_records.id_patient",
      foreignField: "id_patient",
      as: "patient_details"
    }
  },
  {
    $unwind: "$patient_details"
  },
  {
    $project: {
      "patient_name": "$patient_details.name",
      "patient_surname": "$patient_details.surname",
      "birthday": "$patient_details.birthday",
      "gender": "$patient_details.gender",
      "address": "$patient_details.address",
      "city": "$patient_details.city",
      "state": "$patient_details.state",
      "phone": "$patient_details.phone"
    }
  }
])
