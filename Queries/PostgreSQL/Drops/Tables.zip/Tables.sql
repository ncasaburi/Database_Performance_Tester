drop table public.historias_clinicas;
drop table public.paciente_especialista;
drop table public.pacientes;
drop table public.especialistas;