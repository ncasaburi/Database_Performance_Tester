delete from patient_doctor_medical_record
WHERE id_patient in (SELECT id_patient FROM patients WHERE name LIKE 'A%' OR name LIKE 'a%') ;

delete from patient_doctor_medical_record
where id_doctor in (select id_doctor from doctors where profession like 'Gynecology');

delete from patient_doctor_medical_record
where id_medical_record in (select id_medical_record from medical_records WHERE test_results  LIKE 'Abnormal cardiac function test' or test_results like 'Fungal infection');

delete from patient_doctor_medical_record;