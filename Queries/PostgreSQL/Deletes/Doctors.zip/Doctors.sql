delete from  doctors
WHERE name LIKE 'A%' OR name LIKE 'F%';

delete from doctors
WHERE name LIKE 'A%' OR surname LIKE 'F%';


delete from doctors 
WHERE profession like 'Gynecology';

delete from doctors;