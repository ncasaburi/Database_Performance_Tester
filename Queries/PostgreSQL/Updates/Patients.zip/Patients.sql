UPDATE patients
SET birthday = to_date('1971/01/02', 'YYYY/MM/DD')
WHERE name LIKE 'A%' OR name LIKE 'F%';

UPDATE patients
SET name = LOWER(name)
WHERE birthday BETWEEN '1945-01-01' AND '1977-12-31';


update patients 
SET surname = LOWER(surname);

UPDATE patients
SET surname = INITCAP(surname);

